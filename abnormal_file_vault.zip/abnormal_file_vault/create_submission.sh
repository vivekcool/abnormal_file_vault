#!/bin/bash
FILENAME="vivek_sharma_20250504.zip"

# Create temporary directory
TEMP_DIR="./temp_submission"
mkdir -p "$TEMP_DIR"

# Copy required files to temp directory
echo "Copying project files..."

# Backend
mkdir -p "$TEMP_DIR/backend/api"
mkdir -p "$TEMP_DIR/backend/core"
mkdir -p "$TEMP_DIR/backend/file_vault"
mkdir -p "$TEMP_DIR/backend/media/files"

cp -r ./backend/api/* "$TEMP_DIR/backend/api/"
cp -r ./backend/core/* "$TEMP_DIR/backend/core/"
cp -r ./backend/file_vault/* "$TEMP_DIR/backend/file_vault/"
cp ./backend/manage.py "$TEMP_DIR/backend/"
cp ./backend/requirements.txt "$TEMP_DIR/backend/"

# Frontend
mkdir -p "$TEMP_DIR/frontend/public"
mkdir -p "$TEMP_DIR/frontend/src"

cp -r ./frontend/public/* "$TEMP_DIR/frontend/public/"
cp -r ./frontend/src/* "$TEMP_DIR/frontend/src/"
cp ./frontend/package.json "$TEMP_DIR/frontend/"
cp ./frontend/package-lock.json "$TEMP_DIR/frontend/" 2>/dev/null || :

# Docker configuration
mkdir -p "$TEMP_DIR/docker/backend"
mkdir -p "$TEMP_DIR/docker/frontend"

cp ./docker/backend/Dockerfile "$TEMP_DIR/docker/backend/"
cp ./docker/frontend/Dockerfile "$TEMP_DIR/docker/frontend/"
cp ./docker/frontend/nginx.conf "$TEMP_DIR/docker/frontend/"

# Root files
cp ./docker-compose.yml "$TEMP_DIR/"
cp ./README.md "$TEMP_DIR/"

# Create the zip file
echo "Creating submission ZIP file..."
cd "$TEMP_DIR"
zip -r "../$FILENAME" ./* >/dev/null

# Clean up
cd ..
rm -rf "$TEMP_DIR"

# Verify the file was created
if [ -f "$FILENAME" ]; then
  echo "Submission file created successfully: $FILENAME"
  echo "File size: $(du -h "$FILENAME" | cut -f1)"
else
  echo "Error: Failed to create submission file."
  exit 1
fi

echo "Please test the ZIP file before submitting it."