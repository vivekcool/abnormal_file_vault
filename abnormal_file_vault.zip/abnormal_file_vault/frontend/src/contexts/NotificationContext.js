import React, { createContext, useState, useContext, useEffect } from 'react';

// Create the notification context
const NotificationContext = createContext({
  showNotification: () => {},
  hideNotification: () => {},
  notification: null,
});

// Custom hook to use the notification context
export const useNotification = () => useContext(NotificationContext);

export const NotificationProvider = ({ children }) => {
  const [notification, setNotification] = useState(null);
  const [timer, setTimer] = useState(null);

  // Clear timer on unmount
  useEffect(() => {
    return () => {
      if (timer) {
        clearTimeout(timer);
      }
    };
  }, [timer]);

  const showNotification = (message, type = 'info', duration = 5000) => {
    // Clear existing timer
    if (timer) {
      clearTimeout(timer);
    }

    // Set notification
    setNotification({ message, type });

    // Set timer to automatically hide notification
    const newTimer = setTimeout(() => {
      hideNotification();
    }, duration);

    setTimer(newTimer);
  };

  const hideNotification = () => {
    setNotification(null);

    if (timer) {
      clearTimeout(timer);
      setTimer(null);
    }
  };

  return (
    <NotificationContext.Provider value={{
      showNotification,
      hideNotification,
      notification,
    }}>
      {children}

      {/* Render notification */}
      {notification && (
        <div className={`notification ${notification.type}`}>
          <div className="notification-content">
            <p>{notification.message}</p>
            <button onClick={hideNotification} className="close-button">
              &times;
            </button>
          </div>
        </div>
      )}
    </NotificationContext.Provider>
  );
};

export default NotificationProvider;