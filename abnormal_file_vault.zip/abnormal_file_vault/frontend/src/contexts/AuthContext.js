import React, { createContext, useState, useContext, useEffect } from 'react';
import { authService } from '../services/authService';

// Create the auth context
const AuthContext = createContext({
  isAuthenticated: false,
  user: null,
  loading: true,
  login: () => {},
  logout: () => {},
  refreshToken: () => {},
});

// Custom hook to use the auth context
export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if user is already logged in
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check if there's a valid token in local storage
        const currentUser = await authService.getCurrentUser();

        if (currentUser) {
          setUser(currentUser);
          setIsAuthenticated(true);
        }
      } catch (error) {
        // Clear any invalid tokens
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Set up token refresh interval
  useEffect(() => {
    if (!isAuthenticated) return;

    // Refresh token every 50 minutes (token expires after 60)
    const intervalId = setInterval(() => {
      refreshToken();
    }, 50 * 60 * 1000);

    return () => clearInterval(intervalId);
  }, [isAuthenticated]);

  const login = async (username, password) => {
    try {
      const { user, token, refreshToken } = await authService.login(username, password);

      // Store tokens in localStorage
      localStorage.setItem('token', token);
      localStorage.setItem('refreshToken', refreshToken);

      setUser(user);
      setIsAuthenticated(true);

      return user;
    } catch (error) {
      throw new Error(error.message || 'Login failed');
    }
  };

  const logout = () => {
    // Remove tokens from localStorage
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');

    setUser(null);
    setIsAuthenticated(false);
  };

  const refreshToken = async () => {
    try {
      const refreshTokenValue = localStorage.getItem('refreshToken');

      if (!refreshTokenValue) {
        throw new Error('No refresh token found');
      }

      const { token, refreshToken: newRefreshToken } = await authService.refreshToken(refreshTokenValue);

      // Update tokens in localStorage
      localStorage.setItem('token', token);
      localStorage.setItem('refreshToken', newRefreshToken);

      return { token, refreshToken: newRefreshToken };
    } catch (error) {
      // If refresh fails, log the user out
      logout();
      throw new Error('Session expired. Please log in again.');
    }
  };

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      user,
      loading,
      login,
      logout,
      refreshToken,
    }}>
      {children}
    </AuthContext.Provider>
  );
};