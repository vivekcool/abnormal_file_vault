import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fileService } from '../services/fileService';
import { useNotification } from '../contexts/NotificationContext';
import FileSearch from '../components/FileSearch';
import LoadingSpinner from '../components/common/LoadingSpinner';

const FileCard = ({ file }) => {
  const getFileIcon = (fileType) => {
    // Simple file type to icon mapping
    switch(fileType.toLowerCase()) {
      case 'pdf':
        return '📄';
      case 'doc':
      case 'docx':
        return '📝';
      case 'xls':
      case 'xlsx':
        return '📊';
      case 'ppt':
      case 'pptx':
        return '📑';
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return '🖼️';
      case 'mp3':
      case 'wav':
        return '🎵';
      case 'mp4':
      case 'mov':
        return '🎬';
      case 'zip':
      case 'rar':
        return '📦';
      default:
        return '📁';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) {
      return `${bytes} B`;
    } else if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    } else if (bytes < 1024 * 1024 * 1024) {
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    } else {
      return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
    }
  };

  return (
    <div className="file-card">
      <div className="file-card-header">
        <div className="file-icon">
          {getFileIcon(file.file_type)}
        </div>
      </div>

      <div className="file-card-content">
        <h3 className="file-name">{file.name}</h3>

        <div className="file-meta">
          <div>{formatFileSize(file.size)}</div>
          <div>{formatDate(file.created_at)}</div>
        </div>

        {file.tags && file.tags.length > 0 && (
          <div className="file-tags">
            {file.tags.map(tag => (
              <span key={tag.name} className="file-tag">{tag.name}</span>
            ))}
          </div>
        )}

        <div className="file-actions">
          <Link to={`/files/${file.id}`} className="action-button">
            View
          </Link>

          <button
            className="action-button"
            onClick={(e) => {
              e.preventDefault();
              window.open(`/api/files/${file.id}/download/`, '_blank');
            }}
          >
            Download
          </button>
        </div>
      </div>
    </div>
  );
};

const DashboardPage = () => {
  const [files, setFiles] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchParams, setSearchParams] = useState({});
  const [pagination, setPagination] = useState({
    count: 0,
    next: null,
    previous: null,
    currentPage: 1,
  });

  const { showNotification } = useNotification();

  const fetchFiles = async (params = {}, page = 1) => {
    try {
      setIsLoading(true);

      // Add pagination
      const queryParams = {
        ...params,
        page,
      };

      const response = await fileService.getFiles(queryParams);

      setFiles(response.results);
      setPagination({
        count: response.count,
        next: response.next,
        previous: response.previous,
        currentPage: page,
      });
    } catch (error) {
      showNotification(error.message || 'Failed to fetch files', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch files on component mount
  useEffect(() => {
    fetchFiles();
  }, []);

  const handleSearch = (params) => {
    setSearchParams(params);
    fetchFiles(params, 1); // Reset to first page on new search
  };

  const handlePageChange = (newPage) => {
    fetchFiles(searchParams, newPage);
  };

  // Calculate total pages for pagination
  const totalPages = Math.ceil(pagination.count / 50); // Assuming 50 items per page

  return (
    <div>
      <h1>Your Files</h1>

      <FileSearch onSearch={handleSearch} />

      {isLoading ? (
        <LoadingSpinner />
      ) : (
        <>
          <div className="files-container">
            <div className="files-header">
              <h2 className="files-title">
                {searchParams.q
                  ? `Search results for "${searchParams.q}"`
                  : 'All Files'}
              </h2>
              <div>
                {pagination.count} file{pagination.count !== 1 ? 's' : ''} found
              </div>
            </div>

            {files.length > 0 ? (
              <>
                <div className="files-grid">
                  {files.map(file => (
                    <FileCard key={file.id} file={file} />
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="pagination">
                    <button
                      className="pagination-button"
                      onClick={() => handlePageChange(pagination.currentPage - 1)}
                      disabled={!pagination.previous}
                    >
                      Previous
                    </button>

                    {/* Generate page buttons */}
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      // Show 5 pages around current page
                      let pageNum;

                      if (totalPages <= 5) {
                        pageNum = i + 1;
                      } else if (pagination.currentPage <= 3) {
                        pageNum = i + 1;
                      } else if (pagination.currentPage >= totalPages - 2) {
                        pageNum = totalPages - 4 + i;
                      } else {
                        pageNum = pagination.currentPage - 2 + i;
                      }

                      return (
                        <button
                          key={pageNum}
                          className={`pagination-button ${pageNum === pagination.currentPage ? 'active' : ''}`}
                          onClick={() => handlePageChange(pageNum)}
                        >
                          {pageNum}
                        </button>
                      );
                    })}

                    <button
                      className="pagination-button"
                      onClick={() => handlePageChange(pagination.currentPage + 1)}
                      disabled={!pagination.next}
                    >
                      Next
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="empty-state">
                <p>No files found. {searchParams.q ? 'Try a different search term.' : 'Upload some files to get started.'}</p>
                <Link to="/upload" className="button primary" style={{ marginTop: '1rem' }}>
                  Upload Files
                </Link>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default DashboardPage;