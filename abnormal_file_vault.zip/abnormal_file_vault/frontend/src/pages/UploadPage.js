import React from 'react';
import FileUpload from '../components/FileUpload';

const UploadPage = () => {
  return (
    <div>
      <h1>Upload Files</h1>
      <p className="page-description">
        Upload your files securely. The system will automatically deduplicate files,
        saving storage space while maintaining separate file metadata for each upload.
      </p>

      <FileUpload />
    </div>
  );
};

export default UploadPage;