import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fileService } from '../services/fileService';
import { useNotification } from '../contexts/NotificationContext';
import LoadingSpinner from '../components/common/LoadingSpinner';

const FileDetailPage = () => {
  const { fileId } = useParams();
  const [file, setFile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [downloadUrl, setDownloadUrl] = useState('');

  const { showNotification } = useNotification();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchFileDetails = async () => {
      try {
        setIsLoading(true);
        const fileData = await fileService.getFile(fileId);
        setFile(fileData);

        // Fetch download URL
        const downloadData = await fileService.getDownloadUrl(fileId);
        setDownloadUrl(downloadData.download_url);
      } catch (error) {
        showNotification(error.message || 'Failed to fetch file details', 'error');
        navigate('/');
      } finally {
        setIsLoading(false);
      }
    };

    fetchFileDetails();
  }, [fileId, navigate, showNotification]);

  const handleDownload = () => {
    window.open(downloadUrl, '_blank');
  };

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this file? This action cannot be undone.')) {
      try {
        setIsLoading(true);
        await fileService.deleteFile(fileId);

        showNotification('File deleted successfully', 'success');
        navigate('/');
      } catch (error) {
        showNotification(error.message || 'Failed to delete file', 'error');
        setIsLoading(false);
      }
    }
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (!file) {
    return <div>File not found.</div>;
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) {
      return `${bytes} B`;
    } else if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    } else if (bytes < 1024 * 1024 * 1024) {
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    } else {
      return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
    }
  };

  return (
    <div className="file-detail">
      <div className="file-detail-header">
        <div>
          <h1 className="file-detail-name">{file.name}</h1>

          <div className="file-detail-meta">
            Uploaded on {formatDate(file.created_at)}
          </div>

          {file.tags && file.tags.length > 0 && (
            <div className="file-tags">
              {file.tags.map(tag => (
                <span key={tag.name} className="file-tag">{tag.name}</span>
              ))}
            </div>
          )}
        </div>

        <div className="file-detail-actions">
          <button onClick={handleDownload} className="button primary">
            Download
          </button>
          <button onClick={() => navigate(`/files/${fileId}/edit`)} className="button secondary">
            Edit
          </button>
          <button onClick={handleDelete} className="button secondary" style={{ backgroundColor: '#ef4444' }}>
            Delete
          </button>
        </div>
      </div>

      <div className="file-detail-content">
        <div className="file-detail-info">
          <div className="info-section">
            <h3 className="info-title">File Information</h3>

            <div className="info-item">
              <div className="info-label">Type</div>
              <div className="info-value">{file.file_type.toUpperCase()}</div>
            </div>

            <div className="info-item">
              <div className="info-label">Size</div>
              <div className="info-value">{formatFileSize(file.size)}</div>
            </div>

            <div className="info-item">
              <div className="info-label">MIME Type</div>
              <div className="info-value">{file.mime_type}</div>
            </div>

            <div className="info-item">
              <div className="info-label">Last Modified</div>
              <div className="info-value">{formatDate(file.updated_at)}</div>
            </div>

            <div className="info-item">
              <div className="info-label">Last Accessed</div>
              <div className="info-value">{formatDate(file.last_accessed)}</div>
            </div>
          </div>

          {file.description && (
            <div className="info-section">
              <h3 className="info-title">Description</h3>
              <p>{file.description}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FileDetailPage;