import React, { useState, useEffect } from 'react';
import { fileService } from '../services/fileService';
import { useNotification } from '../contexts/NotificationContext';

const FileSearch = ({ onSearch }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [fileType, setFileType] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [tags, setTags] = useState([]);
  const [selectedTags, setSelectedTags] = useState([]);
  const [advancedMode, setAdvancedMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { showNotification } = useNotification();

  // Fetch available tags on component mount
  useEffect(() => {
    const fetchTags = async () => {
      try {
        const response = await fileService.getTags();
        setTags(response.results || []);
      } catch (error) {
        showNotification('Failed to load tags', 'error');
      }
    };

    fetchTags();
  }, [showNotification]);

  const handleSearch = (e) => {
    e.preventDefault();

    // Prepare search parameters
    const searchParams = {};

    if (searchQuery) {
      searchParams.q = searchQuery;
    }

    if (advancedMode) {
      // Add advanced search parameters
      if (fileType) {
        searchParams.type = fileType;
      }

      if (dateFrom) {
        searchParams.date_from = dateFrom;
      }

      if (dateTo) {
        searchParams.date_to = dateTo;
      }

      if (selectedTags.length > 0) {
        searchParams.tags = selectedTags.join(',');
      }
    }

    // Call parent component's onSearch function with the parameters
    onSearch(searchParams);
  };

  const toggleTag = (tagName) => {
    if (selectedTags.includes(tagName)) {
      // Remove tag if already selected
      setSelectedTags(selectedTags.filter(tag => tag !== tagName));
    } else {
      // Add tag if not selected
      setSelectedTags([...selectedTags, tagName]);
    }
  };

  const clearSearch = () => {
    setSearchQuery('');
    setFileType('');
    setDateFrom('');
    setDateTo('');
    setSelectedTags([]);

    // Search with empty parameters to show all files
    onSearch({});
  };

  return (
    <div className="search-container">
      <form onSubmit={handleSearch} className="search-form">
        <div className="search-input-group">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search files..."
            className="search-input"
          />
          <button type="submit" className="search-button" disabled={isLoading}>
            {isLoading ? 'Searching...' : 'Search'}
          </button>
          <button
            type="button"
            onClick={clearSearch}
            className="clear-button"
            disabled={isLoading}
          >
            Clear
          </button>
        </div>

        <div className="advanced-toggle">
          <button
            type="button"
            onClick={() => setAdvancedMode(!advancedMode)}
            className="toggle-button"
          >
            {advancedMode ? 'Hide Advanced Search' : 'Show Advanced Search'}
          </button>
        </div>

        {advancedMode && (
          <div className="advanced-search">
            <div className="form-group">
              <label htmlFor="fileType">File Type</label>
              <select
                id="fileType"
                value={fileType}
                onChange={(e) => setFileType(e.target.value)}
                className="select-input"
              >
                <option value="">All Types</option>
                <option value="pdf">PDF</option>
                <option value="doc,docx">Word Documents</option>
                <option value="xls,xlsx">Excel Spreadsheets</option>
                <option value="ppt,pptx">PowerPoint Presentations</option>
                <option value="jpg,jpeg,png,gif">Images</option>
                <option value="txt">Text Files</option>
              </select>
            </div>

            <div className="date-filters">
              <div className="form-group">
                <label htmlFor="dateFrom">From Date</label>
                <input
                  type="date"
                  id="dateFrom"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="date-input"
                />
              </div>

              <div className="form-group">
                <label htmlFor="dateTo">To Date</label>
                <input
                  type="date"
                  id="dateTo"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="date-input"
                />
              </div>
            </div>

            <div className="tag-selector">
              <label>Tags</label>
              <div className="tags-list">
                {tags.map(tag => (
                  <div
                    key={tag.name}
                    className={`tag ${selectedTags.includes(tag.name) ? 'selected' : ''}`}
                    onClick={() => toggleTag(tag.name)}
                  >
                    {tag.name}
                  </div>
                ))}
                {tags.length === 0 && <p>No tags available</p>}
              </div>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};

export default FileSearch;