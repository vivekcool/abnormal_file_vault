import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fileService } from '../services/fileService';
import { useNotification } from '../contexts/NotificationContext';

const FileUpload = () => {
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const navigate = useNavigate();
  const { showNotification } = useNotification();

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];

    if (selectedFile) {
      setFile(selectedFile);
      // Use the file name as default name, but allow user to change it
      setFileName(selectedFile.name);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      showNotification('Please select a file to upload', 'error');
      return;
    }

    try {
      setIsUploading(true);

      // Create metadata object
      const metadata = {
        name: fileName || file.name,
        description: description || '',
        tags: tags || '',
      };

      // Upload the file
      const uploadedFile = await fileService.uploadFile(file, metadata);

      showNotification('File uploaded successfully!', 'success');

      // Navigate to the file details page
      navigate(`/files/${uploadedFile.id}`);
    } catch (error) {
      showNotification(error.message || 'Failed to upload file', 'error');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <div className="upload-container">
      <h2>Upload File</h2>

      <form onSubmit={handleSubmit} className="upload-form">
        <div className="form-group">
          <label htmlFor="file">Select File</label>
          <input
            type="file"
            id="file"
            onChange={handleFileChange}
            disabled={isUploading}
            className="file-input"
          />
          {file && (
            <div className="file-info">
              <p>
                <strong>Selected:</strong> {file.name}
              </p>
              <p>
                <strong>Size:</strong> {(file.size / 1024).toFixed(2)} KB
              </p>
              <p>
                <strong>Type:</strong> {file.type || 'Unknown'}
              </p>
            </div>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="fileName">File Name</label>
          <input
            type="text"
            id="fileName"
            value={fileName}
            onChange={(e) => setFileName(e.target.value)}
            placeholder="Enter file name"
            disabled={isUploading}
            className="text-input"
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Description (Optional)</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter file description"
            disabled={isUploading}
            className="textarea-input"
          />
        </div>

        <div className="form-group">
          <label htmlFor="tags">Tags (Optional, comma-separated)</label>
          <input
            type="text"
            id="tags"
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            placeholder="e.g. important, work, report"
            disabled={isUploading}
            className="text-input"
          />
        </div>

        {isUploading && (
          <div className="progress-bar-container">
            <div
              className="progress-bar"
              style={{ width: `${uploadProgress}%` }}
            />
            <span className="progress-text">{uploadProgress}%</span>
          </div>
        )}

        <div className="button-group">
          <button
            type="button"
            onClick={() => navigate('/')}
            disabled={isUploading}
            className="button secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isUploading || !file}
            className="button primary"
          >
            {isUploading ? 'Uploading...' : 'Upload File'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default FileUpload;