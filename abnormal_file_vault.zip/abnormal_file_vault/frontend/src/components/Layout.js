import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Layout = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="app-container">
      <header>
        <div className="header-container">
          <NavLink to="/" className="logo">
            Abnormal File Vault
          </NavLink>

          <nav className="nav-links">
            <NavLink
              to="/"
              className={({ isActive }) =>
                isActive ? 'nav-link active' : 'nav-link'
              }
              end
            >
              Files
            </NavLink>

            <NavLink
              to="/upload"
              className={({ isActive }) =>
                isActive ? 'nav-link active' : 'nav-link'
              }
            >
              Upload
            </NavLink>

            <div className="user-menu">
              <span className="user-name">
                {user?.username}
              </span>
              <button
                onClick={handleLogout}
                className="nav-link"
                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
              >
                Logout
              </button>
            </div>
          </nav>
        </div>
      </header>

      <main className="main-content">
        <Outlet />
      </main>

      <footer>
        <div className="header-container">
          <p>&copy; {new Date().getFullYear()} Abnormal Security - File Vault</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;