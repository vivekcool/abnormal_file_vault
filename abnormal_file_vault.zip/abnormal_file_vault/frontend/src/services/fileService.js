import { apiClient } from './apiClient';

export const fileService = {
  /**
   * Get paginated list of files with optional search parameters
   * @param {Object} params - Search parameters
   * @returns {Promise<Object>} Paginated results
   */
  getFiles: async (params = {}) => {
    try {
      const response = await apiClient.get('/files/', { params });
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch files');
    }
  },

  /**
   * Get file details by ID
   * @param {string} fileId - File ID
   * @returns {Promise<Object>} File details
   */
  getFile: async (fileId) => {
    try {
      const response = await apiClient.get(`/files/${fileId}/`);
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch file details');
    }
  },

  /**
   * Upload a new file
   * @param {File} file - File to upload
   * @param {Object} metadata - File metadata
   * @returns {Promise<Object>} Created file object
   */
  uploadFile: async (file, metadata = {}) => {
    try {
      // Create form data
      const formData = new FormData();
      formData.append('file', file);

      // Add metadata fields
      Object.keys(metadata).forEach(key => {
        formData.append(key, metadata[key]);
      });

      const response = await apiClient.post('/files/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      return response.data;
    } catch (error) {
      throw new Error('Failed to upload file');
    }
  },

  /**
   * Update file metadata
   * @param {string} fileId - File ID
   * @param {Object} metadata - Updated metadata
   * @returns {Promise<Object>} Updated file object
   */
  updateFile: async (fileId, metadata) => {
    try {
      const response = await apiClient.patch(`/files/${fileId}/`, metadata);
      return response.data;
    } catch (error) {
      throw new Error('Failed to update file');
    }
  },

  /**
   * Delete a file
   * @param {string} fileId - File ID
   * @returns {Promise<void>}
   */
  deleteFile: async (fileId) => {
    try {
      await apiClient.delete(`/files/${fileId}/`);
    } catch (error) {
      throw new Error('Failed to delete file');
    }
  },

  /**
   * Get download URL for a file
   * @param {string} fileId - File ID
   * @returns {Promise<Object>} Download URL and filename
   */
  getDownloadUrl: async (fileId) => {
    try {
      const response = await apiClient.get(`/files/${fileId}/download/`);
      return response.data;
    } catch (error) {
      throw new Error('Failed to get download URL');
    }
  },

  /**
   * Get file statistics
   * @returns {Promise<Object>} File statistics
   */
  getStats: async () => {
    try {
      const response = await apiClient.get('/files/stats/');
      return response.data;
    } catch (error) {
      throw new Error('Failed to get statistics');
    }
  },

  /**
   * Get tags used by current user
   * @returns {Promise<Array>} List of tags
   */
  getTags: async () => {
    try {
      const response = await apiClient.get('/tags/');
      return response.data;
    } catch (error) {
      throw new Error('Failed to get tags');
    }
  }
};