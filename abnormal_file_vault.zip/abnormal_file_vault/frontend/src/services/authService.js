import { apiClient } from './apiClient';
import jwt_decode from 'jwt-decode';

export const authService = {
  /**
   * Login user and get JWT tokens
   * @param {string} username - User's username
   * @param {string} password - User's password
   * @returns {Promise<Object>} User data and tokens
   */
  login: async (username, password) => {
    try {
      const response = await apiClient.post('/token/', { username, password });
      const { access, refresh } = response.data;

      // Decode JWT to get user info
      const decodedToken = jwt_decode(access);

      return {
        user: {
          id: decodedToken.user_id,
          username: decodedToken.username,
          email: decodedToken.email,
        },
        token: access,
        refreshToken: refresh,
      };
    } catch (error) {
      const message = error.response?.data?.detail || 'Authentication failed';
      throw new Error(message);
    }
  },

  /**
   * Get current logged in user information from token
   * @returns {Promise<Object|null>} User data or null if not authenticated
   */
  getCurrentUser: async () => {
    const token = localStorage.getItem('token');

    if (!token) {
      return null;
    }

    try {
      // Verify token is valid by making a request to the API
      const response = await apiClient.get('/files/?limit=1', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      // If request succeeds, token is valid
      const decodedToken = jwt_decode(token);

      return {
        id: decodedToken.user_id,
        username: decodedToken.username,
        email: decodedToken.email,
      };
    } catch (error) {
      // If request fails, token is invalid
      throw new Error('Invalid token');
    }
  },

  /**
   * Refresh JWT token
   * @param {string} refreshToken - Refresh token
   * @returns {Promise<Object>} New tokens
   */
  refreshToken: async (refreshToken) => {
    try {
      const response = await apiClient.post('/token/refresh/', { refresh: refreshToken });
      const { access, refresh } = response.data;

      return {
        token: access,
        refreshToken: refresh
      };
    } catch (error) {
      throw new Error('Failed to refresh token');
    }
  }
};