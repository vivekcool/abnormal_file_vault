# Abnormal File Vault

A secure and efficient file hosting application with deduplication and advanced search capabilities.

## Features

- **File Deduplication**: Optimize storage by eliminating redundant files
- **Advanced Search & Filtering**: Find files by name, type, date, size, and tags
- **Secure Authentication**: JWT-based authentication system
- **Responsive UI**: Modern UI built with React
- **Containerized Setup**: Easy deployment with Docker and Docker Compose

## Technology Stack

### Backend
- **Django**: Python web framework
- **Django REST Framework**: For building the RESTful API
- **PostgreSQL**: Database for storing file metadata
- **JWT Authentication**: For secure API access

### Frontend
- **React**: JavaScript library for building user interfaces
- **React Router**: For client-side routing
- **Axios**: HTTP client for API requests

### Infrastructure
- **Docker**: For containerization
- **Docker Compose**: For multi-container orchestration

## Project Structure

The project follows a standard structure with separate frontend and backend components:

```
abnormal_file_vault/
├── backend/                    # Django application
│   ├── api/                    # REST API endpoints
│   │   ├── __init__.py
│   │   ├── serializers.py      # Data serialization
│   │   ├── urls.py             # API routing
│   │   └── views.py            # API logic
│   ├── core/                   # Core functionality
│   │   ├── __init__.py
│   │   ├── deduplication.py    # File deduplication logic
│   │   ├── models.py           # Database models
│   │   ├── search.py           # Search functionality
│   │   └── tests.py            # Unit tests
│   ├── file_vault/             # Django project settings
│   │   ├── __init__.py
│   │   ├── asgi.py
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── wsgi.py
│   ├── media/                  # File storage
│   ├── manage.py
│   └── requirements.txt
├── frontend/                   # React application
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/
│   │   │   │   └── LoadingSpinner.js
│   │   │   ├── FileSearch.js
│   │   │   ├── FileUpload.js
│   │   │   └── Layout.js
│   │   ├── contexts/
│   │   │   ├── AuthContext.js
│   │   │   └── NotificationContext.js
│   │   ├── pages/
│   │   │   ├── DashboardPage.js
│   │   │   ├── FilePage.js
│   │   │   ├── LoginPage.js
│   │   │   ├── NotFoundPage.js
│   │   │   └── UploadPage.js
│   │   ├── services/
│   │   │   ├── apiClient.js
│   │   │   ├── authService.js
│   │   │   └── fileService.js
│   │   ├── styles/
│   │   │   └── main.css
│   │   ├── App.js
│   │   └── index.js
│   └── package.json
├── docker/                     # Docker configuration
│   ├── backend/
│   │   └── Dockerfile
│   └── frontend/
│       ├── Dockerfile
│       └── nginx.conf
├── docker-compose.yml          # Multi-container setup
└── README.md                   # Project documentation
```

## How Deduplication Works

The file deduplication system implements a content-based approach:

1. **Hash Calculation**: When a file is uploaded, a SHA-256 hash is calculated from its content
2. **Hash Comparison**: The system checks if a file with the same hash already exists
3. **Storage Optimization**: If a match is found, a new file record is created that points to the existing physical file
4. **Metadata Separation**: File metadata (name, owner, etc.) and physical storage are kept separate

This approach:
- Saves storage space by eliminating redundant data
- Preserves user context by maintaining separate metadata for each file
- Improves performance by reducing I/O operations

## How Search Works

The search system provides powerful capabilities:

1. **Multi-criteria Search**: Find files by name, content, type, date range, size, and tags
2. **Advanced Query Syntax**: Support for operators like `name:`, `type:`, `tag:`, `date>`, `size<`
3. **Full-text Search**: Search within file names and descriptions
4. **Tag-based Filtering**: Organize and find files using tags

## Getting Started

### Prerequisites

- Docker and Docker Compose
- Git

### Installation and Setup

1. Get project zipped files from github or attached file:
   ```bash
   https://github.com/vivekcool/abnormal_file_vault.git
   ```
   And

   Extract the ZIP folder attached containing the application files
   Run the Docker command to start the application:

2. Create required empty directories:
   ```bash
   mkdir -p backend/media/files
   ```

3. Start the application:
   ```bash
   docker-compose up --build
   ```

4. Access the application:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000/api

### Creating an Admin User

To create an admin user for accessing the Django admin interface:

```bash
docker-compose exec backend python manage.py createsuperuser
```

Then access the admin interface at http://localhost:8000/admin

## Running Tests

### Backend Tests

To run the backend tests:

```bash
docker-compose exec backend python manage.py test
```

The tests cover:
- File deduplication functionality
- Search and filtering capabilities
- API endpoint security and functionality

### Manual Testing

1. **Login**: Use an admin user created via `createsuperuser` command
2. **Upload**: Test file upload with various file types
3. **Deduplication**: Upload the same file twice with different names to verify deduplication
4. **Search**: Test search functionality with different criteria
5. **File Management**: Test viewing, downloading, updating, and deleting files

## Usage Examples

### File Upload

1. Log in to the application
2. Click the "Upload" button in the navigation bar
3. Select a file and provide metadata (name, description, tags)
4. Click "Upload File"

### File Search

Basic search:
1. Enter search terms in the search box
2. Press Enter or click the search button

Advanced search:
1. Click "Show Advanced Search"
2. Specify file type, date range, and tags
3. Submit the search

Using search syntax:
- `type:pdf` - Search for PDF files
- `name:report` - Search for files with "report" in the name
- `tag:important` - Search for files with the "important" tag
- `date>2023-01-01` - Search for files created after January 1, 2023

## Performance Considerations

The application is designed for performance and scalability:

- **Efficient Storage**: Deduplication reduces disk usage and I/O operations
- **Indexed Search**: Database indexes optimize search queries
- **Pagination**: Results are paginated to handle large datasets
- **Containerization**: Easy horizontal scaling

## Security Features

- **JWT Authentication**: Secure token-based authentication
- **Permission-based Access**: Users can only access their own files
- **Token Refresh**: Automatic token refreshing for continuous sessions
- **File Isolation**: Secure storage of physical files

## Deployment

For production deployment:

1. Update the environment variables in docker-compose.yml with secure values
2. Configure proper SSL/TLS for HTTPS
3. Set up a proper backup strategy for the database and file storage
4. Consider using a managed database service instead of the containerized PostgreSQL

## Troubleshooting

### Common Issues

1. **Database Connection Errors**:
   - Ensure PostgreSQL container is running: `docker-compose ps`
   - Check database credentials in environment variables

2. **File Upload Issues**:
   - Verify media directory permissions
   - Check file size limits in Django settings and Nginx configuration

3. **Authentication Problems**:
   - Clear browser localStorage and try logging in again
   - Check JWT token expiration settings

### Logs

View application logs:

```bash
# Backend logs
docker-compose logs backend

# Frontend logs
docker-compose logs frontend

# Database logs
docker-compose logs db
```
