from rest_framework import viewsets, status, permissions
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.db.models import Count
from django.db import transaction

from core.models import UserFile, Tag
from core.deduplication import FileDeduplicator
from core.search import FileSearch
from .serializers import (
    UserFileSerializer,
    UserFileDetailSerializer,
    TagSerializer
)

import mimetypes
import os


class UserFileViewSet(viewsets.ModelViewSet):
    """
    API endpoint for user files with search, upload, and management capabilities
    """
    serializer_class = UserFileSerializer
    parser_classes = [MultiPartParser, FormParser]
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """Return files owned by the current user"""
        return UserFile.objects.filter(owner=self.request.user)

    def get_serializer_class(self):
        """Use detailed serializer for retrieve actions"""
        if self.action == 'retrieve':
            return UserFileDetailSerializer
        return UserFileSerializer

    def list(self, request):
        """List files with search and filtering support"""
        # Check if we're performing a search
        if any(key in request.query_params for key in
               ['q', 'type', 'tags', 'date_from', 'date_to', 'size_min', 'size_max']):
            queryset = FileSearch.search(request.user, request.query_params)
        else:
            queryset = self.get_queryset().order_by('-created_at')

        # Support for advanced search syntax
        if 'query' in request.query_params:
            search_params = FileSearch.parse_search_query(request.query_params['query'])
            queryset = FileSearch.search(request.user, search_params)

        # Handle pagination
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        """Retrieve file details and update last_accessed time"""
        instance = self.get_object()

        # Update last accessed time
        instance.last_accessed = timezone.now()
        instance.save(update_fields=['last_accessed'])

        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    @transaction.atomic
    def create(self, request):
        """
        Upload a new file with deduplication

        Request should include:
        - file: The file data
        - name: Optional name (defaults to original filename)
        - description: Optional description
        - tag_list: Optional list of tags
        """
        # Validate required fields
        if 'file' not in request.FILES:
            return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)

        uploaded_file = request.FILES['file']

        # Process the file through deduplication system
        file_hash, is_new = FileDeduplicator.deduplicate(uploaded_file)

        # Determine file type and MIME type
        filename = request.data.get('name', uploaded_file.name)
        file_extension = os.path.splitext(uploaded_file.name)[1].lower()[1:]  # Remove dot
        mime_type, _ = mimetypes.guess_type(uploaded_file.name)

        # Create user file record
        user_file_data = {
            'name': filename,
            'description': request.data.get('description', ''),
            'file_type': file_extension,
            'mime_type': mime_type or 'application/octet-stream',
            'owner': request.user,
            'file_hash': file_hash
        }

        # Handle tags if provided
        tag_list = []
        if 'tags' in request.data:
            tag_list = request.data['tags'].split(',')

        serializer = self.get_serializer(data=user_file_data)
        serializer.is_valid(raise_exception=True)

        # Pass tag_list to serializer's create method
        serializer.save(tag_list=tag_list, **user_file_data)

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['get'])
    def download(self, request, pk=None):
        """Get download URL for a file"""
        from django.conf import settings
        from django.urls import reverse

        instance = self.get_object()
        file_path = instance.file_hash.file_path

        # Update last accessed time
        instance.last_accessed = timezone.now()
        instance.save(update_fields=['last_accessed'])

        # Generate download URL
        media_url = settings.MEDIA_URL
        download_url = f"{media_url}{file_path}"

        return Response({
            'download_url': download_url,
            'filename': instance.name
        })

    @action(detail=False, methods=['get'])
    def stats(self, request):
        """Get statistics about user's files"""
        user_files = self.get_queryset()

        # Count files by type
        type_stats = user_files.values('file_type').annotate(count=Count('id'))

        # Total storage used
        total_size = sum(f.size for f in user_files)

        # Storage saved through deduplication
        # Number of files that share file_hash with at least one other file
        duplicated_count = 0
        saved_bytes = 0

        # Get all file hashes used by this user
        file_hashes = set(user_files.values_list('file_hash_id', flat=True))

        # For each hash, count how many files share it
        for hash_id in file_hashes:
            files_with_hash = UserFile.objects.filter(file_hash_id=hash_id)
            count = files_with_hash.count()

            if count > 1:
                # Files with this hash are duplicates
                file_size = files_with_hash.first().size
                duplicated_count += count - 1  # Count all except the first one
                saved_bytes += file_size * (count - 1)  # Size saved

        return Response({
            'total_files': user_files.count(),
            'total_size': total_size,
            'type_distribution': type_stats,
            'duplicated_files': duplicated_count,
            'storage_saved': saved_bytes
        })


class TagViewSet(viewsets.ReadOnlyModelViewSet):
    """API endpoint for file tags"""
    serializer_class = TagSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """Return tags used by the current user"""
        return Tag.objects.filter(files__owner=self.request.user).distinct()