from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from .views import UserFileViewSet, TagViewSet

# Create a router and register our viewsets
router = DefaultRouter()
router.register(r'files', UserFileViewSet, basename='file')
router.register(r'tags', TagViewSet, basename='tag')

urlpatterns = [
    # API endpoints
    path('', include(router.urls)),

    # Authentication
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]