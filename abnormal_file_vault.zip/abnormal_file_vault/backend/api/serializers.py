from rest_framework import serializers
from django.contrib.auth.models import User
from core.models import UserFile, FileHash, Tag


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['name']


class FileHashSerializer(serializers.ModelSerializer):
    class Meta:
        model = FileHash
        fields = ['hash_value', 'size', 'created_at']


class UserFileSerializer(serializers.ModelSerializer):
    tags = TagSerializer(many=True, read_only=True)
    size = serializers.IntegerField(read_only=True)
    owner_username = serializers.SerializerMethodField()
    tag_list = serializers.ListField(
        child=serializers.CharField(max_length=100),
        write_only=True,
        required=False
    )

    class Meta:
        model = UserFile
        fields = [
            'id', 'name', 'description', 'file_type', 'mime_type',
            'created_at', 'updated_at', 'last_accessed', 'tags',
            'size', 'owner_username', 'tag_list'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'last_accessed', 'size']

    def get_owner_username(self, obj):
        return obj.owner.username

    def create(self, validated_data):
        tag_list = validated_data.pop('tag_list', [])
        user_file = UserFile.objects.create(**validated_data)

        # Add tags
        for tag_name in tag_list:
            tag, _ = Tag.objects.get_or_create(name=tag_name)
            user_file.tags.add(tag)

        return user_file

    def update(self, instance, validated_data):
        tag_list = validated_data.pop('tag_list', None)

        # Update UserFile fields
        instance.name = validated_data.get('name', instance.name)
        instance.description = validated_data.get('description', instance.description)
        instance.save()

        # Update tags if provided
        if tag_list is not None:
            # Clear existing tags
            instance.tags.clear()

            # Add new tags
            for tag_name in tag_list:
                tag, _ = Tag.objects.get_or_create(name=tag_name)
                instance.tags.add(tag)

        return instance


class UserFileDetailSerializer(UserFileSerializer):
    file_hash = FileHashSerializer(read_only=True)

    class Meta(UserFileSerializer.Meta):
        fields = UserFileSerializer.Meta.fields + ['file_hash']


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']
        read_only_fields = ['id']