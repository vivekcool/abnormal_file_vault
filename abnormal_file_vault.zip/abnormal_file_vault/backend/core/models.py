from django.db import models
from django.contrib.auth.models import User
import uuid
import os
from django.utils import timezone


def file_upload_path(instance, filename):
    """Generate a unique path for uploaded files"""
    ext = filename.split('.')[-1]
    filename = f"{uuid.uuid4()}.{ext}"
    return os.path.join('uploads', filename)


class FileHash(models.Model):
    """Store file hashes for deduplication"""
    hash_value = models.CharField(max_length=64, unique=True)  # SHA-256 hash
    file_path = models.CharField(max_length=255)  # Path to physical file
    size = models.BigIntegerField()  # File size in bytes
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.hash_value} ({self.size} bytes)"


class UserFile(models.Model):
    """User's file metadata"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    file_type = models.CharField(max_length=100)
    mime_type = models.CharField(max_length=100)

    # Foreign keys
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='files')
    file_hash = models.ForeignKey(FileHash, on_delete=models.CASCADE, related_name='user_files')

    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_accessed = models.DateTimeField(default=timezone.now)

    # Tags (for search functionality)
    tags = models.ManyToManyField('Tag', blank=True, related_name='files')

    class Meta:
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['file_type']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return f"{self.name} - {self.owner.username}"

    @property
    def size(self):
        """Get file size from the associated FileHash"""
        return self.file_hash.size

    @property
    def file_path(self):
        """Get file path from the associated FileHash"""
        return self.file_hash.file_path


class Tag(models.Model):
    """Tags for categorizing and searching files"""
    name = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name