from django.db.models import Q
from datetime import datetime
import re
from .models import UserFile, Tag


class FileSearch:
    """
    Advanced search functionality for user files with
    support for multiple search criteria and filters
    """

    @staticmethod
    def search(user, query_params):
        """
        Search for files with complex filtering options

        Args:
            user: User instance performing the search
            query_params: Dict of search parameters

        Returns:
            QuerySet of UserFile objects matching search criteria
        """
        # Start with all files owned by the user
        queryset = UserFile.objects.filter(owner=user)

        # Text search (name, description)
        if 'q' in query_params and query_params['q']:
            search_term = query_params['q']
            queryset = queryset.filter(
                Q(name__icontains=search_term) |
                Q(description__icontains=search_term)
            )

        # File type filter
        if 'type' in query_params and query_params['type']:
            file_types = query_params['type'].split(',')
            queryset = queryset.filter(file_type__in=file_types)

        # Date range filter for created_at
        if 'date_from' in query_params and query_params['date_from']:
            try:
                date_from = datetime.fromisoformat(query_params['date_from'])
                queryset = queryset.filter(created_at__gte=date_from)
            except ValueError:
                pass  # Invalid date format, ignore filter

        if 'date_to' in query_params and query_params['date_to']:
            try:
                date_to = datetime.fromisoformat(query_params['date_to'])
                queryset = queryset.filter(created_at__lte=date_to)
            except ValueError:
                pass  # Invalid date format, ignore filter

        # Size range filter (in bytes)
        if 'size_min' in query_params and query_params['size_min']:
            try:
                size_min = int(query_params['size_min'])
                queryset = queryset.filter(file_hash__size__gte=size_min)
            except ValueError:
                pass  # Invalid size format, ignore filter

        if 'size_max' in query_params and query_params['size_max']:
            try:
                size_max = int(query_params['size_max'])
                queryset = queryset.filter(file_hash__size__lte=size_max)
            except ValueError:
                pass  # Invalid size format, ignore filter

        # Tags filter
        if 'tags' in query_params and query_params['tags']:
            tag_list = query_params['tags'].split(',')
            for tag in tag_list:
                queryset = queryset.filter(tags__name=tag.strip())

        # Sorting
        if 'sort' in query_params and query_params['sort']:
            sort_field = query_params['sort']
            allowed_fields = ['name', '-name', 'created_at', '-created_at',
                              'updated_at', '-updated_at']

            if sort_field in allowed_fields:
                queryset = queryset.order_by(sort_field)

        return queryset

    @staticmethod
    def parse_search_query(search_text):
        """
        Parse advanced search query with support for operators
        Example: "name:report type:pdf date>2023-01-01"

        Args:
            search_text: String containing advanced search query

        Returns:
            Dict of parsed search parameters
        """
        result = {'q': ''}
        remaining_text = search_text

        # Define patterns for different search operators
        patterns = {
            'name': r'name:([^\s]+)',
            'type': r'type:([^\s]+)',
            'tag': r'tag:([^\s]+)',
            'date>': r'date>([^\s]+)',
            'date<': r'date<([^\s]+)',
            'size>': r'size>([^\s]+)',
            'size<': r'size<([^\s]+)',
        }

        # Extract parameters using patterns
        for key, pattern in patterns.items():
            matches = re.findall(pattern, search_text)
            if matches:
                if key == 'name':
                    result['q'] = matches[0]
                elif key == 'type':
                    result['type'] = matches[0]
                elif key == 'tag':
                    if 'tags' not in result:
                        result['tags'] = matches[0]
                    else:
                        result['tags'] += f",{matches[0]}"
                elif key == 'date>':
                    result['date_from'] = matches[0]
                elif key == 'date<':
                    result['date_to'] = matches[0]
                elif key == 'size>':
                    result['size_min'] = matches[0]
                elif key == 'size<':
                    result['size_max'] = matches[0]

                # Remove matched part from remaining text
                remaining_text = re.sub(pattern, '', remaining_text)

        # Any remaining text becomes part of the general search
        remaining_text = remaining_text.strip()
        if remaining_text and not result['q']:
            result['q'] = remaining_text

        return result