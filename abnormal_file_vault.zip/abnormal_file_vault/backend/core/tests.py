from django.test import TestCase
from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from rest_framework.test import APIClient
from rest_framework import status
import tempfile
import os

from .models import UserFile, FileHash, Tag
from .deduplication import FileDeduplicator
from .search import FileSearch


class DeduplicationTest(TestCase):
    def setUp(self):
        # Create a test user
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )

        # Create a temporary file for testing
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        # Clean up temporary files
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_file_hash_calculation(self):
        """Test hash calculation for files"""
        # Create a test file with known content
        content = b"Test file content for hash calculation"
        test_file = SimpleUploadedFile("test_file.txt", content)

        # Calculate hash
        hash_value = FileDeduplicator.calculate_hash(test_file)

        # Expected SHA-256 hash for this content
        expected_hash = "8efb6cd84aae95df05d5c9c0b33c751b1639372b7699709be04f61ef226aef89"

        # Assert the hash matches expected value
        self.assertEqual(hash_value, expected_hash)

    def test_file_deduplication(self):
        """Test that identical files are deduplicated"""
        # Create two identical files
        content = b"Test file content for deduplication"
        file1 = SimpleUploadedFile("file1.txt", content)
        file2 = SimpleUploadedFile("file2.txt", content)

        # Process the first file
        file_hash1, is_new1 = FileDeduplicator.deduplicate(file1)

        # First file should be marked as new
        self.assertTrue(is_new1)

        # Process the second file
        file_hash2, is_new2 = FileDeduplicator.deduplicate(file2)

        # Second file should not be marked as new
        self.assertFalse(is_new2)

        # Both file hashes should be the same object
        self.assertEqual(file_hash1.id, file_hash2.id)


class SearchTest(TestCase):
    def setUp(self):
        # Create a test user
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )

        # Create a test file hash
        self.file_hash = FileHash.objects.create(
            hash_value="test_hash_123",
            file_path="test/path/file.txt",
            size=1024
        )

        # Create some test files with different attributes
        self.file1 = UserFile.objects.create(
            name="Document1.pdf",
            description="Important document",
            file_type="pdf",
            mime_type="application/pdf",
            owner=self.user,
            file_hash=self.file_hash
        )

        self.file2 = UserFile.objects.create(
            name="Image1.jpg",
            description="Holiday photo",
            file_type="jpg",
            mime_type="image/jpeg",
            owner=self.user,
            file_hash=self.file_hash
        )

        self.file3 = UserFile.objects.create(
            name="Report.xlsx",
            description="Financial report",
            file_type="xlsx",
            mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            owner=self.user,
            file_hash=self.file_hash
        )

        # Create some tags
        self.tag1 = Tag.objects.create(name="important")
        self.tag2 = Tag.objects.create(name="work")
        self.tag3 = Tag.objects.create(name="personal")

        # Assign tags to files
        self.file1.tags.add(self.tag1, self.tag2)
        self.file2.tags.add(self.tag3)
        self.file3.tags.add(self.tag1, self.tag2)

    def test_basic_search(self):
        """Test basic search functionality"""
        # Search for PDF files
        query_params = {'type': 'pdf'}
        results = FileSearch.search(self.user, query_params)

        # Should return only file1
        self.assertEqual(results.count(), 1)
        self.assertEqual(results.first().id, self.file1.id)

    def test_text_search(self):
        """Test text search in name and description"""
        # Search for "report" in name or description
        query_params = {'q': 'report'}
        results = FileSearch.search(self.user, query_params)

        # Should return only file3
        self.assertEqual(results.count(), 1)
        self.assertEqual(results.first().id, self.file3.id)

    def test_tag_search(self):
        """Test searching by tags"""
        # Search for files with tag "important"
        query_params = {'tags': 'important'}
        results = FileSearch.search(self.user, query_params)

        # Should return file1 and file3
        self.assertEqual(results.count(), 2)
        result_ids = [f.id for f in results]
        self.assertIn(self.file1.id, result_ids)
        self.assertIn(self.file3.id, result_ids)

    def test_combined_search(self):
        """Test combining multiple search criteria"""
        # Search for important Excel files
        query_params = {
            'type': 'xlsx',
            'tags': 'important'
        }
        results = FileSearch.search(self.user, query_params)

        # Should return only file3
        self.assertEqual(results.count(), 1)
        self.assertEqual(results.first().id, self.file3.id)

    def test_advanced_query_parsing(self):
        """Test parsing advanced search queries"""
        # Test query: "type:pdf tag:important"
        parsed = FileSearch.parse_search_query("type:pdf tag:important")

        self.assertEqual(parsed['type'], 'pdf')
        self.assertEqual(parsed['tags'], 'important')


class APITest(TestCase):
    def setUp(self):
        # Create test users
        self.user1 = User.objects.create_user(
            username='user1',
            email='user1@example.com',
            password='testpass123'
        )

        self.user2 = User.objects.create_user(
            username='user2',
            email='user2@example.com',
            password='testpass123'
        )

        # Set up API client
        self.client = APIClient()

        # Create a test file hash
        self.file_hash = FileHash.objects.create(
            hash_value="api_test_hash_456",
            file_path="test/path/apifile.txt",
            size=2048
        )

        # Create test files for user1
        self.file1 = UserFile.objects.create(
            name="User1_Document.pdf",
            description="User1's document",
            file_type="pdf",
            mime_type="application/pdf",
            owner=self.user1,
            file_hash=self.file_hash
        )

        # Create test files for user2
        self.file2 = UserFile.objects.create(
            name="User2_Document.pdf",
            description="User2's document",
            file_type="pdf",
            mime_type="application/pdf",
            owner=self.user2,
            file_hash=self.file_hash
        )

    def test_file_list(self):
        """Test file listing API"""
        # Authenticate as user1
        self.client.force_authenticate(user=self.user1)

        # Get file list
        response = self.client.get('/api/files/')

        # Check response
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Should only see user1's files
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['name'], "User1_Document.pdf")

    def test_file_upload(self):
        """Test file upload API"""
        # Authenticate as user1
        self.client.force_authenticate(user=self.user1)

        # Create test file
        test_file = SimpleUploadedFile(
            "test_upload.txt",
            b"File content for API upload test",
            content_type="text/plain"
        )

        # Upload file
        response = self.client.post(
            '/api/files/',
            {'file': test_file, 'name': 'API Test File', 'description': 'Uploaded via API'},
            format='multipart'
        )

        # Check response
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['name'], 'API Test File')

        # Verify file was saved
        self.assertTrue(UserFile.objects.filter(name='API Test File').exists())

    def test_unauthorized_access(self):
        """Test that users cannot access each other's files"""
        # Authenticate as user2
        self.client.force_authenticate(user=self.user2)

        # Try to access user1's file
        response = self.client.get(f'/api/files/{self.file1.id}/')

        # Should get 404 because file belongs to different user
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)