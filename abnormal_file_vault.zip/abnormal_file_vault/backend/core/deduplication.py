import hashlib
import os
import logging
from django.conf import settings
from .models import FileHash

logger = logging.getLogger(__name__)


class FileDeduplicator:
    """
    Handles file deduplication by calculating and comparing file hashes.
    Uses SHA-256 for reliable file content comparison.
    """

    @staticmethod
    def calculate_hash(file_obj):
        """
        Calculate SHA-256 hash of file content

        Args:
            file_obj: Django UploadedFile or file-like object

        Returns:
            str: Hexadecimal digest of SHA-256 hash
        """
        sha256 = hashlib.sha256()
        # Reset file pointer to beginning
        file_obj.seek(0)

        # Read file in chunks to efficiently handle large files
        for chunk in iter(lambda: file_obj.read(4096), b''):
            sha256.update(chunk)

        # Reset file pointer for subsequent operations
        file_obj.seek(0)

        return sha256.hexdigest()

    @staticmethod
    def deduplicate(file_obj):
        """
        Check if file already exists based on content hash.
        If exists, return existing FileHash instance, otherwise save new file.

        Args:
            file_obj: Django UploadedFile object

        Returns:
            tuple: (FileHash instance, bool indicating if newly created)
        """
        hash_value = FileDeduplicator.calculate_hash(file_obj)
        file_size = file_obj.size

        # Check if file with same hash already exists
        try:
            existing_file = FileHash.objects.get(hash_value=hash_value)
            logger.info(f"Duplicate file detected: {hash_value}")
            return existing_file, False
        except FileHash.DoesNotExist:
            # File doesn't exist, save it
            file_path = FileDeduplicator._save_file(file_obj, hash_value)

            file_hash = FileHash(
                hash_value=hash_value,
                file_path=file_path,
                size=file_size
            )
            file_hash.save()

            logger.info(f"New file saved: {hash_value}")
            return file_hash, True

    @staticmethod
    def _save_file(file_obj, hash_value):
        """
        Save file to storage with hash-based filename

        Args:
            file_obj: Django UploadedFile object
            hash_value: SHA-256 hash of file

        Returns:
            str: Path where file is saved
        """
        # Create directory structure based on first few chars of hash for better organization
        hash_prefix = hash_value[:2]
        dir_path = os.path.join(settings.MEDIA_ROOT, 'files', hash_prefix)

        # Create directory if it doesn't exist
        os.makedirs(dir_path, exist_ok=True)

        # Determine file extension
        original_name = file_obj.name
        extension = os.path.splitext(original_name)[1].lower()

        # Create filename from hash and original extension
        filename = f"{hash_value}{extension}"
        file_path = os.path.join('files', hash_prefix, filename)
        full_path = os.path.join(settings.MEDIA_ROOT, file_path)

        # Save file
        with open(full_path, 'wb+') as destination:
            for chunk in file_obj.chunks():
                destination.write(chunk)

        return file_path